import { Component } from '@angular/core';

@Component({
  selector: 'app-welcome-hotels',
  templateUrl: './welcome-hotels.component.html',
  styleUrl: './welcome-hotels.component.css'
})
export class WelcomeHotelsComponent {

}
