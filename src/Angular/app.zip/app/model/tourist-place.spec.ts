import { TouristPlace } from './tourist-place';

describe('TouristPlace', () => {
  it('should create an instance', () => {
    expect(new TouristPlace()).toBeTruthy();
  });
});
